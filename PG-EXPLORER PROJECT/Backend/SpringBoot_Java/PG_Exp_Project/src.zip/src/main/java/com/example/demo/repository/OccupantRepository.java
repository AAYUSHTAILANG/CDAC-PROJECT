package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.demo.entities.Occupant;
import com.example.demo.entities.Users;

@Repository
public interface OccupantRepository extends JpaRepository<Occupant, Integer> {

	@Query("select o from Occupant o where user_id = ?1")
	Occupant getOccupant(Users u);

}
