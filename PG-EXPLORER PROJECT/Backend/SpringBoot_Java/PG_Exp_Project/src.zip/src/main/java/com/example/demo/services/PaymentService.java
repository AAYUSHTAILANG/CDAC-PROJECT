package com.example.demo.services;

import org.springframework.stereotype.Service;

import com.example.demo.repository.PaymentRepository;
@Service
public class PaymentService {
	
	PaymentRepository pay_repo;

}
