package com.example.demo.entities;

public class occRequestDummy {
		
	private int occupant_id;
	private int property_id;
	public int getOccupant_id() {
		return occupant_id;
	}
	public void setOccupant_id(int occupant_id) {
		this.occupant_id = occupant_id;
	}
	public int getProperty_id() {
		return property_id;
	}
	public void setProperty_id(int property_id) {
		this.property_id = property_id;
	}
	public occRequestDummy() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
