import React from "react";
import AdminNavbar from "./AdminNavbar";

function RemoveOwner() {
  return (
    <div>
      <div>
        <h1>Remove Owner</h1>
      </div>
    </div>
  );
}
export default RemoveOwner;
