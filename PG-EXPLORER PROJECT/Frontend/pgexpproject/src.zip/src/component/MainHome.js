import React from 'react';
import './mainhome.css'; 
import CarouselComponent from './Carousel';
export default function MainHome() {
  return (
    <CarouselComponent/>
  );
}
