import React from "react";

function AdminMain() {
  return <h1>Admin main</h1>;
}

export default AdminMain;
