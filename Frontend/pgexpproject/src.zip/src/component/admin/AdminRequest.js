import React from "react";
import AdminNavbar from "./AdminNavbar";

function AdminRequest() {
  return (
    <>
      <div>
        <div>
          <h1>Owner Request</h1>
        </div>
      </div>
    </>
  );
}
export default AdminRequest;
