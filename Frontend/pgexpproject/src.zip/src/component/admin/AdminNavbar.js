import { Link, Route, Routes } from "react-router-dom";
import AdminRequest from "./AdminRequest";
import RemoveOwner from "./RemoveOwner";
import Logout from "../Logout";
import AdminMain from "./AdminMain";

function AdminNavbar() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div
          className="col-auto col-md-2 min-vh-100"
          style={{ backgroundColor: "rgba(0, 123, 255, 0.5)" }}
        >
          <a className="text-decoration-none text-white d-flex align-itemcenter">
            <span className="ms-1 fs-4">Admin</span>
          </a>
          <ul className="nav nav-pills flex-column">
            <li className="nav-item fs-4">
              <Link
                to="admin_main"
                className="nav-link btn btn-outline-light px-3"
              >
                Home
              </Link>
            </li>
            <li className="nav-item fs-4">
              <Link
                to="accept_request"
                className="nav-link btn btn-outline-light px-3"
              >
                Accept Request
              </Link>
            </li>
            <li className="nav-item fs-4">
              <Link
                to="remove_owner"
                className="nav-link btn btn-outline-light px-3"
              >
                Remove Owner
              </Link>
            </li>
            <li className="nav-item fs-4">
              <Link
                to="/logout"
                className="nav-link btn btn-outline-light px-3"
              >
                Logout
              </Link>
            </li>
          </ul>
        </div>
        <div className="col">
          <Routes>
            <Route path="/admin_main" element={<AdminMain />} />
            <Route path="/accept_request" element={<AdminRequest />} />
            <Route path="/remove_owner" element={<RemoveOwner />} />
            <Route path="/logout" element={<Logout />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}

export default AdminNavbar;
